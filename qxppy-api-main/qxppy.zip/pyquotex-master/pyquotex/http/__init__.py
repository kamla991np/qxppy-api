"""Module for Quotex API http."""
